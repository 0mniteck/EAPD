# Evil Access Point Defender
Protect your Wireless Network from Bad Access Points.

Runs smoothly on the Wifi-Pineapple MK7, but still in nightly builds.

Download: <a target="_blank" href="https://github.com/0mniteck/EAPD/archive/master.zip">Current Pre-Release</a>

Check out the wiki: <a target="_blank" href="https://github.com/0mniteck/EAPD/wiki/Wiki">Github/0mniteck/EAPD/Wiki</a>

Updated Last: 1/8/2021
