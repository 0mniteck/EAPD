#!/usr/bin/env python3
import logging

from pineapple.modules import Module, Request

module = Module('eapd', logging.DEBUG)

@module.handles_action('get_log')
def get_log(request: Request):
    return 'Sample Log...\n imagine it here...\n'

if __name__ == '__main__': 
    module.start()
